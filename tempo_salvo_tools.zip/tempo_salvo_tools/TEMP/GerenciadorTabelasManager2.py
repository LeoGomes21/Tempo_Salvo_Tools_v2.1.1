from qgis.PyQt.QtWidgets import (QDialog, QTableWidgetItem, QAbstractItemView, QHeaderView, QShortcut)
from qgis.core import QgsProject, QgsMessageLog, Qgis, QgsVectorLayer, QgsWkbTypes
from qgis.PyQt.QtGui import QKeySequence
from qgis.PyQt.QtCore import Qt, QSignalBlocker
from qgis.utils import iface
from qgis.PyQt import uic
import os
import re

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'GerenciadordeTabelas.ui'))

class TabelasManager(QDialog, FORM_CLASS):
    def __init__(self, iface, plugin, parent=None):
        """Constructor."""
        super(TabelasManager, self).__init__(parent)
        # Configura a interface do usuário a partir do Designer.
        self.setupUi(self)

        self.iface = iface  # Armazena a referência da interface QGIS
        self.plugin = plugin        # Guarda a referência ao plugin

        self.setWindowFlags(
            self.windowFlags()
            | Qt.WindowType.Window
            | Qt.WindowType.WindowMinimizeButtonHint)

        # controle interno para evitar conexões duplicadas
        self._project_signals_connected = False
        self._connected_layer_ids = set()

        self._current_table_layer = None
        self._table_sync_guard = False

        self._setup_table_widgets()

        # Altera o título da janela
        self.setWindowTitle("Gerenciador de Tabelas")

        # Conecta os sinais aos slots
        self.connect_signals()

    def connect_signals(self):
        """Conecta sinais básicos da UI."""
        self.radioButtonLinha.toggled.connect(self.update_combo_box_item)
        self.radioButtonPoligono.toggled.connect(self.update_combo_box_item)
        self.radioButtonPonto.toggled.connect(self.update_combo_box_item)

        self.comboBoxCamada.currentIndexChanged.connect(self._on_current_layer_changed)

        self.tableWidgetCampo.itemSelectionChanged.connect(
            self._on_tablewidgetcampo_selection_changed)

        self.tableWidgetCampo.itemChanged.connect(self._on_tablewidgetcampo_item_changed)
        self.tableWidgetAtributos.itemChanged.connect(self._on_tablewidgetatributos_item_changed)

        # atalhos mais intuitivos
        self._shortcut_move_up = QShortcut(QKeySequence("Ctrl+Up"), self.tableWidgetCampo)
        self._shortcut_move_down = QShortcut(QKeySequence("Ctrl+Down"), self.tableWidgetCampo)

        self._shortcut_move_up.activated.connect(self._move_selected_field_up)
        self._shortcut_move_down.activated.connect(self._move_selected_field_down)

        # menu de contexto
        self.tableWidgetCampo.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.tableWidgetCampo.customContextMenuRequested.connect(
            self._show_tablewidgetcampo_context_menu)

    def showEvent(self, event):
        """
        Sobrescreve o evento de exibição do diálogo para resetar os Widgets
        e conectar sinais dinâmicos do projeto/camadas.
        """
        super(TabelasManager, self).showEvent(event)

        self._connect_project_signals()
        self._connect_layer_signals()
        self._refresh_layer_ui()
        self._on_current_layer_changed()

    def _log_message(self, message, level=Qgis.MessageLevel.Info):
        """Opcional para visualizar erros"""
        QgsMessageLog.logMessage(message, 'Malha', level=level)

    def mostrar_mensagem(self, texto, tipo, duracao=3, caminho_pasta=None, caminho_arquivo=None):
        """
        Exibe uma mensagem na barra de mensagens do QGIS, proporcionando feedback ao usuário baseado nas ações realizadas.
        As mensagens podem ser de erro ou de sucesso, com uma duração configurável e uma opção de abrir uma pasta.

        :param texto: Texto da mensagem a ser exibida.
        :param tipo: Tipo da mensagem ("Erro" ou "Sucesso") que determina a cor e o ícone da mensagem.
        :param duracao: Duração em segundos durante a qual a mensagem será exibida (padrão é 3 segundos).
        :param caminho_pasta: Caminho da pasta a ser aberta ao clicar no botão (padrão é None).
        :param caminho_arquivo: Caminho do arquivo a ser executado ao clicar no botão (padrão é None).
        """
        # Obtém a barra de mensagens da interface do QGIS
        bar = self.iface.messageBar()  # Acessa a barra de mensagens da interface do QGIS

        # Exibe a mensagem com o nível apropriado baseado no tipo
        if tipo == "Erro":
            # Mostra uma mensagem de erro na barra de mensagens com um ícone crítico e a duração especificada
            bar.pushMessage("Erro", texto, level=Qgis.MessageLevel.Critical, duration=duracao)
        elif tipo == "Sucesso":
            # Cria o item da mensagem
            msg = bar.createMessage("Sucesso", texto)

    def populate_combo_box(self):
        """
        Avalia as camadas vetoriais do projeto, habilita/desabilita os rádios
        conforme os tipos existentes e define a seleção inicial.
        """
        project_layers = QgsProject.instance().mapLayers().values()

        line_layers = []
        polygon_layers = []
        point_layers = []

        for layer in project_layers:
            try:
                if not isinstance(layer, QgsVectorLayer):
                    continue
                if not layer.isValid():
                    continue

                geom_type = layer.geometryType()

                if geom_type == QgsWkbTypes.LineGeometry:
                    line_layers.append(layer)
                elif geom_type == QgsWkbTypes.PolygonGeometry:
                    polygon_layers.append(layer)
                elif geom_type == QgsWkbTypes.PointGeometry:
                    point_layers.append(layer)
            except Exception as e:
                layer_name = layer.name() if hasattr(layer, "name") else "sem_nome"
                self._log_message(
                    f"Erro ao avaliar camada '{layer_name}': {e}",
                    Qgis.MessageLevel.Warning)

        has_lines = bool(line_layers)
        has_polygons = bool(polygon_layers)
        has_points = bool(point_layers)

        previous_selection = None
        if self.radioButtonLinha.isChecked():
            previous_selection = "linha"
        elif self.radioButtonPoligono.isChecked():
            previous_selection = "poligono"
        elif self.radioButtonPonto.isChecked():
            previous_selection = "ponto"

        blockers = [
            QSignalBlocker(self.radioButtonLinha),
            QSignalBlocker(self.radioButtonPoligono),
            QSignalBlocker(self.radioButtonPonto),
            QSignalBlocker(self.comboBoxCamada)]

        try:
            self.radioButtonLinha.setEnabled(has_lines)
            self.radioButtonPoligono.setEnabled(has_polygons)
            self.radioButtonPonto.setEnabled(has_points)

            self.radioButtonLinha.setChecked(False)
            self.radioButtonPoligono.setChecked(False)
            self.radioButtonPonto.setChecked(False)

            # tenta preservar a seleção atual, se ainda existir
            if previous_selection == "linha" and has_lines:
                self.radioButtonLinha.setChecked(True)
            elif previous_selection == "poligono" and has_polygons:
                self.radioButtonPoligono.setChecked(True)
            elif previous_selection == "ponto" and has_points:
                self.radioButtonPonto.setChecked(True)
            else:
                # regra inicial padrão
                if has_lines:
                    self.radioButtonLinha.setChecked(True)
                elif has_polygons:
                    self.radioButtonPoligono.setChecked(True)
                elif has_points:
                    self.radioButtonPonto.setChecked(True)
                else:
                    self.comboBoxCamada.clear()
                    self.comboBoxCamada.setEnabled(False)
                    return

            self.comboBoxCamada.setEnabled(True)

        finally:
            del blockers

        self.update_combo_box_item()
    
    def update_combo_box_item(self):
        """
        Atualiza o comboBoxCamada de acordo com o tipo geométrico selecionado
        nos radio buttons.
        """
        current_layer_id = self.comboBoxCamada.currentData()

        self.comboBoxCamada.clear()

        project_layers = QgsProject.instance().mapLayers().values()
        selected_layers = []

        for layer in project_layers:
            if not isinstance(layer, QgsVectorLayer):
                continue
            if not layer.isValid():
                continue

            geom_type = layer.geometryType()

            if self.radioButtonLinha.isChecked() and geom_type == QgsWkbTypes.LineGeometry:
                selected_layers.append(layer)
            elif self.radioButtonPoligono.isChecked() and geom_type == QgsWkbTypes.PolygonGeometry:
                selected_layers.append(layer)
            elif self.radioButtonPonto.isChecked() and geom_type == QgsWkbTypes.PointGeometry:
                selected_layers.append(layer)

        selected_layers.sort(key=lambda lyr: lyr.name().lower())

        restore_index = -1
        for i, layer in enumerate(selected_layers):
            self.comboBoxCamada.addItem(layer.name(), layer.id())
            if layer.id() == current_layer_id:
                restore_index = i

        self.comboBoxCamada.setEnabled(self.comboBoxCamada.count() > 0)

        if restore_index >= 0:
            self.comboBoxCamada.setCurrentIndex(restore_index)
        elif self.comboBoxCamada.count() > 0:
            self.comboBoxCamada.setCurrentIndex(0)

        self._on_current_layer_changed() # Atualiza as Tabelas

    def _setup_table_widgets(self):
        """Configura visual e comportamento das tabelas de campos e atributos."""
        for table, title in (
            (self.tableWidgetCampo, "Campos"),
            (self.tableWidgetAtributos, "Atributos")):
            table.setColumnCount(1)
            table.setHorizontalHeaderLabels([title])
            table.setRowCount(0)

            table.horizontalHeader().setStretchLastSection(True)
            table.horizontalHeader().setSectionResizeMode(
                0, QHeaderView.ResizeMode.Stretch)
            table.verticalHeader().setVisible(False)
            table.verticalHeader().setDefaultSectionSize(28)

            table.setSelectionBehavior(
                QAbstractItemView.SelectionBehavior.SelectRows)
            table.setSelectionMode(
                QAbstractItemView.SelectionMode.SingleSelection)

            table.setEditTriggers(
                QAbstractItemView.EditTrigger.DoubleClicked
                | QAbstractItemView.EditTrigger.EditKeyPressed
                | QAbstractItemView.EditTrigger.SelectedClicked)

            table.setAlternatingRowColors(True)
            table.setSortingEnabled(False)
            table.setWordWrap(False)

            font = table.font()
            font.setPointSize(font.pointSize() + 1)
            table.setFont(font)

        # Reordenação controlada por código, mais estável no Qt6
        self.tableWidgetCampo.setDragEnabled(False)
        self.tableWidgetCampo.setAcceptDrops(False)
        self.tableWidgetCampo.viewport().setAcceptDrops(False)
        self.tableWidgetCampo.setDragDropMode(
            QAbstractItemView.DragDropMode.NoDragDrop)

        self.tableWidgetAtributos.setDragDropMode(
            QAbstractItemView.DragDropMode.NoDragDrop)

    def _selected_vector_layer(self):
        """Retorna a camada vetorial atualmente selecionada no combo."""
        layer_id = self.comboBoxCamada.currentData()
        if not layer_id:
            return None

        layer = QgsProject.instance().mapLayer(layer_id)
        if not isinstance(layer, QgsVectorLayer):
            return None
        if not layer.isValid():
            return None
        return layer

    def _on_current_layer_changed(self, *args):
        """Atualiza tabelas e reconecta sinais da camada atualmente selecionada."""
        self._connect_current_layer_table_signals()
        self._load_selected_layer_tables()
        self._load_attributes_for_selected_field()

    def _connect_current_layer_table_signals(self):
        """
        Conecta os sinais da camada atual usados para manter as tabelas em sincronia
        com alterações estruturais da camada.
        """
        if self._current_table_layer is not None:
            try:
                self._current_table_layer.updatedFields.disconnect(self._load_selected_layer_tables)
            except Exception:
                pass

        self._current_table_layer = self._selected_vector_layer()

        if self._current_table_layer is not None:
            try:
                self._current_table_layer.updatedFields.connect(self._load_selected_layer_tables)
            except Exception:
                pass

    def _load_selected_layer_tables(self, *args):
        """Carrega os campos da camada atual na tabela de campos."""
        layer = self._selected_vector_layer()

        blockers = [
            QSignalBlocker(self.tableWidgetCampo),
            QSignalBlocker(self.tableWidgetAtributos)]

        try:
            self.tableWidgetCampo.setRowCount(0)
            self.tableWidgetAtributos.setRowCount(0)

            if layer is None:
                return

            fields = layer.fields()

            for field_idx, field in enumerate(fields):
                row_campo = self.tableWidgetCampo.rowCount()
                self.tableWidgetCampo.insertRow(row_campo)

                item_campo = QTableWidgetItem(field.name())
                item_campo.setData(Qt.ItemDataRole.UserRole, field_idx)
                item_campo.setData(Qt.ItemDataRole.UserRole + 1, field.name())
                item_campo.setFlags(
                    item_campo.flags()
                    | Qt.ItemFlag.ItemIsEditable
                    | Qt.ItemFlag.ItemIsDragEnabled
                    | Qt.ItemFlag.ItemIsDropEnabled)
                self._apply_item_style(item_campo)
                self.tableWidgetCampo.setItem(row_campo, 0, item_campo)

            self.tableWidgetCampo.resizeRowsToContents()

            if self.tableWidgetCampo.rowCount() > 0:
                self.tableWidgetCampo.selectRow(0)

        finally:
            del blockers

    def _apply_item_style(self, item):
        """Aplica alinhamento padrão aos itens das tabelas."""
        item.setTextAlignment(int(Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft))

    def _find_row_by_field_id(self, table, field_id):
        """Retorna a linha correspondente ao field_id na tabela."""
        for row in range(table.rowCount()):
            item = table.item(row, 0)
            if item and item.data(Qt.ItemDataRole.UserRole) == field_id:
                return row
        return -1

    def _sync_item_to_other_table(self, source_table, target_table, item):
        """
        Espelha a edição de um item da tabela fonte para a tabela destino,
        usando o mesmo field_id como identificação.
        """
        if self._table_sync_guard or item is None:
            return

        field_id = item.data(Qt.ItemDataRole.UserRole)
        if field_id is None:
            return

        target_row = self._find_row_by_field_id(target_table, field_id)
        if target_row < 0:
            return

        target_item = target_table.item(target_row, 0)
        if target_item is None:
            return

        self._table_sync_guard = True
        try:
            target_item.setText(item.text())
            self._apply_item_style(target_item)
            target_item.setData(Qt.ItemDataRole.UserRole + 1, item.text())
            item.setData(Qt.ItemDataRole.UserRole + 1, item.text())
        finally:
            self._table_sync_guard = False

    def _on_tablewidgetcampo_item_changed(self, item):
        """Mantém estilo após edição em Campos e recarrega atributos se necessário."""
        if item is None:
            return
        self._apply_item_style(item)

    def _on_tablewidgetatributos_item_changed(self, item):
        """Mantém estilo após edição em Atributos."""
        if item is None:
            return
        self._apply_item_style(item)

    def _selected_field_index(self):
        """Retorna o índice do campo atualmente selecionado em Campos."""
        row = self.tableWidgetCampo.currentRow()
        if row < 0:
            return None

        item = self.tableWidgetCampo.item(row, 0)
        if item is None:
            return None

        return item.data(Qt.ItemDataRole.UserRole)

    def _on_tablewidgetcampo_selection_changed(self):
        """Atualiza a lista de atributos quando o campo selecionado muda."""
        self._load_attributes_for_selected_field()

    def _load_attributes_for_selected_field(self):
        """
        Carrega em Atributos os valores únicos do campo selecionado em Campos.
        """
        layer = self._selected_vector_layer()
        field_idx = self._selected_field_index()

        blocker = QSignalBlocker(self.tableWidgetAtributos)
        try:
            self.tableWidgetAtributos.setRowCount(0)

            if layer is None or field_idx is None:
                return

            unique_values = set()

            for feat in layer.getFeatures():
                try:
                    value = feat[field_idx]
                except Exception:
                    continue

                if value is None:
                    continue

                text = str(value).strip()
                if not text:
                    continue

                unique_values.add(text)

            for value in sorted(unique_values, key=lambda x: x.lower()):
                row = self.tableWidgetAtributos.rowCount()
                self.tableWidgetAtributos.insertRow(row)

                item_attr = QTableWidgetItem(value)
                item_attr.setData(Qt.ItemDataRole.UserRole, field_idx)
                item_attr.setData(Qt.ItemDataRole.UserRole + 1, value)
                item_attr.setFlags(
                    item_attr.flags()
                    | Qt.ItemFlag.ItemIsEditable)
                self._apply_item_style(item_attr)
                self.tableWidgetAtributos.setItem(row, 0, item_attr)

            self.tableWidgetAtributos.resizeRowsToContents()

        finally:
            del blocker

    def _swap_rows_text_and_ids(self, table, row_a, row_b):
        """Troca conteúdo e metadados entre duas linhas da tabela."""
        if row_a < 0 or row_b < 0:
            return
        if row_a >= table.rowCount() or row_b >= table.rowCount():
            return
        if row_a == row_b:
            return

        item_a = table.takeItem(row_a, 0)
        item_b = table.takeItem(row_b, 0)

        table.setItem(row_a, 0, item_b)
        table.setItem(row_b, 0, item_a)

        if table.item(row_a, 0):
            self._apply_item_style(table.item(row_a, 0))
        if table.item(row_b, 0):
            self._apply_item_style(table.item(row_b, 0))

    def _move_selected_field_up(self):
        """Move o campo selecionado uma linha para cima."""
        table = self.tableWidgetCampo
        row = table.currentRow()

        if row <= 0:
            return

        blocker = QSignalBlocker(self.tableWidgetCampo)
        try:
            self._swap_rows_text_and_ids(self.tableWidgetCampo, row, row - 1)
            table.selectRow(row - 1)
        finally:
            del blocker

    def _move_selected_field_down(self):
        """Move o campo selecionado uma linha para baixo."""
        table = self.tableWidgetCampo
        row = table.currentRow()

        if row < 0 or row >= table.rowCount() - 1:
            return

        blocker = QSignalBlocker(self.tableWidgetCampo)
        try:
            self._swap_rows_text_and_ids(self.tableWidgetCampo, row, row + 1)
            table.selectRow(row + 1)
        finally:
            del blocker

    def _refresh_layer_ui(self, *args, **kwargs):
        """
        Atualiza radios, combo e reconecta sinais das camadas quando necessário.
        Aceita *args para ser usado diretamente como slot de sinais do QGIS.
        """
        self._connect_layer_signals()
        self.populate_combo_box()

    def _show_tablewidgetcampo_context_menu(self, pos):
        """Exibe menu de contexto para reordenar campos."""
        table = self.tableWidgetCampo
        if table.rowCount() == 0:
            return

        row = table.currentRow()
        if row < 0:
            item = table.itemAt(pos)
            if item is not None:
                row = item.row()
                table.selectRow(row)

        if row < 0:
            return

        menu = QMenu(table)

        action_up = menu.addAction("Mover para cima")
        action_down = menu.addAction("Mover para baixo")

        action_up.setEnabled(row > 0)
        action_down.setEnabled(row < table.rowCount() - 1)

        chosen = menu.exec(table.viewport().mapToGlobal(pos))
        if chosen == action_up:
            self._move_selected_field_up()
        elif chosen == action_down:
            self._move_selected_field_down()

    def _connect_project_signals(self):
        """
        Conecta sinais do projeto apenas uma vez.
        """
        if self._project_signals_connected:
            return

        project = QgsProject.instance()

        try:
            project.layersAdded.connect(self._refresh_layer_ui)
        except Exception:
            pass

        try:
            project.layersRemoved.connect(self._refresh_layer_ui)
        except Exception:
            pass

        try:
            project.layerWasAdded.connect(self._refresh_layer_ui)
        except Exception:
            pass

        self._project_signals_connected = True

    def _disconnect_project_signals(self):
        """
        Desconecta sinais do projeto.
        """
        if not self._project_signals_connected:
            return

        project = QgsProject.instance()

        for signal in (
            getattr(project, "layersAdded", None),
            getattr(project, "layersRemoved", None),
            getattr(project, "layerWasAdded", None)):
            if signal is None:
                continue
            try:
                signal.disconnect(self._refresh_layer_ui)
            except Exception:
                pass

        self._project_signals_connected = False

    def _connect_layer_signals(self):
        """
        Conecta sinais relevantes de camadas vetoriais válidas.
        Atualmente observa mudança de nome da camada.
        """
        project_layers = QgsProject.instance().mapLayers().values()
        current_ids = set()

        for layer in project_layers:
            if not isinstance(layer, QgsVectorLayer):
                continue
            if not layer.isValid():
                continue

            layer_id = layer.id()
            current_ids.add(layer_id)

            if layer_id in self._connected_layer_ids:
                continue

            try:
                layer.nameChanged.connect(self._refresh_layer_ui)
                self._connected_layer_ids.add(layer_id)
            except Exception:
                pass

        # limpa ids de camadas que saíram do projeto
        removed_ids = self._connected_layer_ids - current_ids
        if removed_ids:
            self._connected_layer_ids -= removed_ids

    def _disconnect_layer_signals(self):
        """
        Desconecta sinais das camadas atualmente no projeto.
        """
        project_layers = QgsProject.instance().mapLayers().values()

        for layer in project_layers:
            if not isinstance(layer, QgsVectorLayer):
                continue
            if not layer.isValid():
                continue

            try:
                layer.nameChanged.disconnect(self._refresh_layer_ui)
            except Exception:
                pass

        self._connected_layer_ids.clear()

    def _nome_unico_no_projeto(self, base_name: str) -> str:
        """
        Gera um nome único dentro do QgsProject.

        Parameters
        base_name : str
            Nome base proposto para a camada (sem sufixo numérico).

        Returns
        str
            Nome único: base_name, base_name_1, base_name_2, ...
        """
        existing = {lyr.name() for lyr in QgsProject.instance().mapLayers().values()}
        if base_name not in existing:
            return base_name

        counter = 1
        while f"{base_name}_{counter}" in existing:
            counter += 1
        return f"{base_name}_{counter}"

    def closeEvent(self, event):
        """
        Em vez de destruir o diálogo, apenas oculta e limpa conexões dinâmicas.
        """
        if self._current_table_layer is not None:
            try:
                self._current_table_layer.updatedFields.disconnect(self._load_selected_layer_tables)
            except Exception:
                pass
            self._current_table_layer = None

        self._disconnect_project_signals()
        self._disconnect_layer_signals()

        self.hide()
        event.ignore()
