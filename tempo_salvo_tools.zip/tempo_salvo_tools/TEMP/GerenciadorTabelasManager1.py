from qgis.PyQt.QtWidgets import QDialog, QCheckBox, QComboBox
from qgis.core import QgsProject, QgsMessageLog, Qgis, QgsVectorLayer, QgsWkbTypes, QgsCoordinateReferenceSystem, QgsMapSettings
from qgis.PyQt.QtGui import QImage, QPainter, QColor, QPixmap
from qgis.PyQt.QtCore import Qt, QSignalBlocker
from qgis.utils import iface
from qgis.PyQt import uic
import os

FORM_CLASS, _ = uic.loadUiType(os.path.join(
    os.path.dirname(__file__), 'GerenciadordeTabelas.ui'))

class TabelasManager(QDialog, FORM_CLASS):
    def __init__(self, iface, plugin, parent=None):
        """Constructor."""
        super(TabelasManager, self).__init__(parent)
        # Configura a interface do usuário a partir do Designer.
        self.setupUi(self)

        self.iface = iface  # Armazena a referência da interface QGIS
        self.plugin = plugin        # Guarda a referência ao plugin

        self.setWindowFlags(
            self.windowFlags()
            | Qt.WindowType.Window
            | Qt.WindowType.WindowMinimizeButtonHint)

        # controle interno para evitar conexões duplicadas
        self._project_signals_connected = False
        self._connected_layer_ids = set()

        # Altera o título da janela
        self.setWindowTitle("Gerenciador de Tabelas")

        # Conecta os sinais aos slots
        self.connect_signals()

    def connect_signals(self):
        """Conecta sinais básicos da UI."""
        self.radioButtonLinha.toggled.connect(self.update_combo_box_item)
        self.radioButtonPoligono.toggled.connect(self.update_combo_box_item)
        self.radioButtonPonto.toggled.connect(self.update_combo_box_item)

    def showEvent(self, event):
        """
        Sobrescreve o evento de exibição do diálogo para resetar os Widgets
        e conectar sinais dinâmicos do projeto/camadas.
        """
        super(TabelasManager, self).showEvent(event)

        self._connect_project_signals()
        self._connect_layer_signals()
        self._refresh_layer_ui()

    def _log_message(self, message, level=Qgis.MessageLevel.Info):
        """Opcional para visualizar erros"""
        QgsMessageLog.logMessage(message, 'Malha', level=level)

    def mostrar_mensagem(self, texto, tipo, duracao=3, caminho_pasta=None, caminho_arquivo=None):
        """
        Exibe uma mensagem na barra de mensagens do QGIS, proporcionando feedback ao usuário baseado nas ações realizadas.
        As mensagens podem ser de erro ou de sucesso, com uma duração configurável e uma opção de abrir uma pasta.

        :param texto: Texto da mensagem a ser exibida.
        :param tipo: Tipo da mensagem ("Erro" ou "Sucesso") que determina a cor e o ícone da mensagem.
        :param duracao: Duração em segundos durante a qual a mensagem será exibida (padrão é 3 segundos).
        :param caminho_pasta: Caminho da pasta a ser aberta ao clicar no botão (padrão é None).
        :param caminho_arquivo: Caminho do arquivo a ser executado ao clicar no botão (padrão é None).
        """
        # Obtém a barra de mensagens da interface do QGIS
        bar = self.iface.messageBar()  # Acessa a barra de mensagens da interface do QGIS

        # Exibe a mensagem com o nível apropriado baseado no tipo
        if tipo == "Erro":
            # Mostra uma mensagem de erro na barra de mensagens com um ícone crítico e a duração especificada
            bar.pushMessage("Erro", texto, level=Qgis.MessageLevel.Critical, duration=duracao)
        elif tipo == "Sucesso":
            # Cria o item da mensagem
            msg = bar.createMessage("Sucesso", texto)

    def populate_combo_box(self):
        """
        Avalia as camadas vetoriais do projeto, habilita/desabilita os rádios
        conforme os tipos existentes e define a seleção inicial.
        """
        project_layers = QgsProject.instance().mapLayers().values()

        line_layers = []
        polygon_layers = []
        point_layers = []

        for layer in project_layers:
            try:
                if not isinstance(layer, QgsVectorLayer):
                    continue
                if not layer.isValid():
                    continue

                geom_type = layer.geometryType()

                if geom_type == QgsWkbTypes.LineGeometry:
                    line_layers.append(layer)
                elif geom_type == QgsWkbTypes.PolygonGeometry:
                    polygon_layers.append(layer)
                elif geom_type == QgsWkbTypes.PointGeometry:
                    point_layers.append(layer)
            except Exception as e:
                layer_name = layer.name() if hasattr(layer, "name") else "sem_nome"
                self._log_message(
                    f"Erro ao avaliar camada '{layer_name}': {e}",
                    Qgis.MessageLevel.Warning)

        has_lines = bool(line_layers)
        has_polygons = bool(polygon_layers)
        has_points = bool(point_layers)

        previous_selection = None
        if self.radioButtonLinha.isChecked():
            previous_selection = "linha"
        elif self.radioButtonPoligono.isChecked():
            previous_selection = "poligono"
        elif self.radioButtonPonto.isChecked():
            previous_selection = "ponto"

        blockers = [
            QSignalBlocker(self.radioButtonLinha),
            QSignalBlocker(self.radioButtonPoligono),
            QSignalBlocker(self.radioButtonPonto),
            QSignalBlocker(self.comboBoxCamada)]

        try:
            self.radioButtonLinha.setEnabled(has_lines)
            self.radioButtonPoligono.setEnabled(has_polygons)
            self.radioButtonPonto.setEnabled(has_points)

            self.radioButtonLinha.setChecked(False)
            self.radioButtonPoligono.setChecked(False)
            self.radioButtonPonto.setChecked(False)

            # tenta preservar a seleção atual, se ainda existir
            if previous_selection == "linha" and has_lines:
                self.radioButtonLinha.setChecked(True)
            elif previous_selection == "poligono" and has_polygons:
                self.radioButtonPoligono.setChecked(True)
            elif previous_selection == "ponto" and has_points:
                self.radioButtonPonto.setChecked(True)
            else:
                # regra inicial padrão
                if has_lines:
                    self.radioButtonLinha.setChecked(True)
                elif has_polygons:
                    self.radioButtonPoligono.setChecked(True)
                elif has_points:
                    self.radioButtonPonto.setChecked(True)
                else:
                    self.comboBoxCamada.clear()
                    self.comboBoxCamada.setEnabled(False)
                    return

            self.comboBoxCamada.setEnabled(True)

        finally:
            del blockers

        self.update_combo_box_item()
    
    def update_combo_box_item(self):
        """
        Atualiza o comboBoxCamada de acordo com o tipo geométrico selecionado
        nos radio buttons.
        """
        current_layer_id = self.comboBoxCamada.currentData()

        self.comboBoxCamada.clear()

        project_layers = QgsProject.instance().mapLayers().values()
        selected_layers = []

        for layer in project_layers:
            if not isinstance(layer, QgsVectorLayer):
                continue
            if not layer.isValid():
                continue

            geom_type = layer.geometryType()

            if self.radioButtonLinha.isChecked() and geom_type == QgsWkbTypes.LineGeometry:
                selected_layers.append(layer)
            elif self.radioButtonPoligono.isChecked() and geom_type == QgsWkbTypes.PolygonGeometry:
                selected_layers.append(layer)
            elif self.radioButtonPonto.isChecked() and geom_type == QgsWkbTypes.PointGeometry:
                selected_layers.append(layer)

        selected_layers.sort(key=lambda lyr: lyr.name().lower())

        restore_index = -1
        for i, layer in enumerate(selected_layers):
            self.comboBoxCamada.addItem(layer.name(), layer.id())
            if layer.id() == current_layer_id:
                restore_index = i

        self.comboBoxCamada.setEnabled(self.comboBoxCamada.count() > 0)

        if restore_index >= 0:
            self.comboBoxCamada.setCurrentIndex(restore_index)
        elif self.comboBoxCamada.count() > 0:
            self.comboBoxCamada.setCurrentIndex(0)

    def _refresh_layer_ui(self, *args, **kwargs):
        """
        Atualiza radios, combo e reconecta sinais das camadas quando necessário.
        Aceita *args para ser usado diretamente como slot de sinais do QGIS.
        """
        self._connect_layer_signals()
        self.populate_combo_box()

    def _connect_project_signals(self):
        """
        Conecta sinais do projeto apenas uma vez.
        """
        if self._project_signals_connected:
            return

        project = QgsProject.instance()

        try:
            project.layersAdded.connect(self._refresh_layer_ui)
        except Exception:
            pass

        try:
            project.layersRemoved.connect(self._refresh_layer_ui)
        except Exception:
            pass

        try:
            project.layerWasAdded.connect(self._refresh_layer_ui)
        except Exception:
            pass

        self._project_signals_connected = True

    def _disconnect_project_signals(self):
        """
        Desconecta sinais do projeto.
        """
        if not self._project_signals_connected:
            return

        project = QgsProject.instance()

        for signal in (
            getattr(project, "layersAdded", None),
            getattr(project, "layersRemoved", None),
            getattr(project, "layerWasAdded", None)):
            if signal is None:
                continue
            try:
                signal.disconnect(self._refresh_layer_ui)
            except Exception:
                pass

        self._project_signals_connected = False

    def _connect_layer_signals(self):
        """
        Conecta sinais relevantes de camadas vetoriais válidas.
        Atualmente observa mudança de nome da camada.
        """
        project_layers = QgsProject.instance().mapLayers().values()
        current_ids = set()

        for layer in project_layers:
            if not isinstance(layer, QgsVectorLayer):
                continue
            if not layer.isValid():
                continue

            layer_id = layer.id()
            current_ids.add(layer_id)

            if layer_id in self._connected_layer_ids:
                continue

            try:
                layer.nameChanged.connect(self._refresh_layer_ui)
                self._connected_layer_ids.add(layer_id)
            except Exception:
                pass

        # limpa ids de camadas que saíram do projeto
        removed_ids = self._connected_layer_ids - current_ids
        if removed_ids:
            self._connected_layer_ids -= removed_ids

    def _disconnect_layer_signals(self):
        """
        Desconecta sinais das camadas atualmente no projeto.
        """
        project_layers = QgsProject.instance().mapLayers().values()

        for layer in project_layers:
            if not isinstance(layer, QgsVectorLayer):
                continue
            if not layer.isValid():
                continue

            try:
                layer.nameChanged.disconnect(self._refresh_layer_ui)
            except Exception:
                pass

        self._connected_layer_ids.clear()

    def _nome_unico_no_projeto(self, base_name: str) -> str:
        """
        Gera um nome único dentro do QgsProject.

        Parameters
        base_name : str
            Nome base proposto para a camada (sem sufixo numérico).

        Returns
        str
            Nome único: base_name, base_name_1, base_name_2, ...
        """
        existing = {lyr.name() for lyr in QgsProject.instance().mapLayers().values()}
        if base_name not in existing:
            return base_name

        counter = 1
        while f"{base_name}_{counter}" in existing:
            counter += 1
        return f"{base_name}_{counter}"

    def closeEvent(self, event):
        """
        Em vez de destruir o diálogo, apenas oculta e limpa conexões dinâmicas.
        """
        self._disconnect_project_signals()
        self._disconnect_layer_signals()

        self.hide()
        event.ignore()